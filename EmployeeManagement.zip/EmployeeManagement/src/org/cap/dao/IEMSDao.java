package org.cap.dao;

import java.util.List;

import org.cap.exception.EmployeeMaintenanceSystemException;
import org.cap.model.DepartmentBean;
import org.cap.model.EmployeeBean;

public interface IEMSDao {

	public boolean isValidEmployee(String name, String password) throws EmployeeMaintenanceSystemException;

	public boolean isValidAdmin(String name, String password) throws EmployeeMaintenanceSystemException;

	public EmployeeBean getEmployeeDetails(String empid) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllEmployeeDetails() throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllEmployeeDetails(String empid) throws EmployeeMaintenanceSystemException;

	public Integer UpdateDetails(String empid,String fname, String lname, Integer deptId,
			String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact) throws EmployeeMaintenanceSystemException;

	public Integer addEmployeeDetails(EmployeeBean employee) throws EmployeeMaintenanceSystemException;

	public List<EmployeeBean> getAllEmployeeDetails1(String fname) throws EmployeeMaintenanceSystemException;

	public List<DepartmentBean> displayDepartmentDetails();

	public List<EmployeeBean> getAllEmployeeDetails2(Integer deptId);

	public List<EmployeeBean> getAllEmployeeDetailsGrade(String grade);

	public List<EmployeeBean> getAllEmployeeDetailsStatus(String marital);



}
