package org.cap.dao;

public class QueryMapper {

	public static final String CHECK_USER="select * from user_master where username=? AND  userpassword=? And usertype=?;";
}
