package org.cap.service;

import java.util.List;

import org.cap.dao.EMSDaoImpl;
import org.cap.dao.IEMSDao;
import org.cap.exception.EmployeeMaintenanceSystemException;
import org.cap.model.DepartmentBean;
import org.cap.model.EmployeeBean;

public class EMSServiceImpl implements IEMSService{

	private IEMSDao empDao=new EMSDaoImpl();
	
	@Override
	public boolean isValidEmployee(String name, String password) throws EmployeeMaintenanceSystemException{
		
		if(empDao.isValidEmployee(name,password)){
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public boolean isValidAdmin(String name, String password) throws EmployeeMaintenanceSystemException{
		
		
		
		if(empDao.isValidAdmin(name,password)){
			return true;
		}
		else
		{
			return false;
		}
	}

	@Override
	public EmployeeBean getEmployeeDetails(String empid) throws EmployeeMaintenanceSystemException{
		
		EmployeeBean empBean=empDao.getEmployeeDetails(empid);
		
		return empBean;
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetails() throws EmployeeMaintenanceSystemException{
		List<EmployeeBean> employeeList=empDao.getAllEmployeeDetails();
		return employeeList;
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetails(String empid) throws EmployeeMaintenanceSystemException{
		
		List<EmployeeBean> employeeList=empDao.getAllEmployeeDetails(empid);
		return employeeList;
	}

	@Override
	public Integer UpdateDetails(String empid,String fname, String lname, Integer deptId,
			String grade, String designation, Integer basic,
			String maritalStatus, String hAddress, String contact) throws EmployeeMaintenanceSystemException{
		
		Integer Update=empDao.UpdateDetails(empid,fname,lname,deptId,grade,designation,basic,maritalStatus,hAddress,contact);
		return Update;
	}

	@Override
	public Integer addEmployeeDetails(EmployeeBean bean) throws EmployeeMaintenanceSystemException{
		
		Integer add=empDao.addEmployeeDetails(bean);
		return add;
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetails1(String fname)
			throws EmployeeMaintenanceSystemException {
		List<EmployeeBean> employeeList=empDao.getAllEmployeeDetails1(fname);
		return employeeList;
	}

	@Override
	public List<DepartmentBean> displayDepartmentDetails() {
 List<DepartmentBean> bean=empDao.displayDepartmentDetails();
		
		return bean;
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetails2(Integer deptId) {
		
		List<EmployeeBean> employeeList=empDao.getAllEmployeeDetails2(deptId);
		return employeeList;
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetailsGrade(String grade) {
		List<EmployeeBean> employeeList=empDao.getAllEmployeeDetailsGrade(grade);
		return employeeList;
	}

	@Override
	public List<EmployeeBean> getAllEmployeeDetailsStatus(String marital) {
		List<EmployeeBean> employeeList=empDao.getAllEmployeeDetailsStatus(marital);
		return employeeList;
	}

}
