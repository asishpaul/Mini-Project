package org.cap.service;

import java.util.regex.Pattern;

public class Validation {

	public Boolean isValidEmpId(String empId){

		if(empId==null){
			return false;
		}
		else{
			//String employeeId=empId.toString();
			String regex="^[1-9][0-9]{5}$";
			return Pattern.matches(regex,empId);
		}
	}

	public Boolean isValidFirstName(String fname){

		if(fname==null){
			return false;
		}
		else{
			String regex="^[a-zA-Z]*$";
			return Pattern.matches(regex,fname);
		}
	}
	
	public Boolean isValidLastName(String lname){

		if(lname==null){
			return false;
		}
		else{
			String regex="^[a-zA-Z]*$";
			return Pattern.matches(regex,lname);
		}
	}
	
	public Boolean isValidDOB(String empDateOfBirth){

		if(empDateOfBirth==null){
			return false;
		}
		else{
			String regex="^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$";
			return Pattern.matches(regex,empDateOfBirth);
		}
	}
	
	public Boolean isValidDOJ(String empDateOfJoining){

		if(empDateOfJoining==null){
			return false;
		}
		else{
			String regex="^(3[01]|[12][0-9]|0[1-9])/(1[0-2]|0[1-9])/[0-9]{4}$";
			return Pattern.matches(regex,empDateOfJoining);
		}
	}
	
	public Boolean isValidGrade(String grade){

		if(grade==null){
			return false;
		}
		else{
			String regex="^[M][1-7]$";
			return Pattern.matches(regex,grade);
		}
	}
	
	public Boolean isValidGender(String gender){
		if(gender==null){
			return false;
		}else{
			String regex="^male|^female|^Male|^Female|^M|^F$";
			return Pattern.matches(regex,gender);
		}

	}
	
	public Boolean isValidMartialStatus(String martialStatus){
		if(martialStatus==null){
			return false;
		}else{
			String regex="^Single|^Married|^Divorced|^Seperated|^Widowed$";
			return Pattern.matches(regex,martialStatus);
		}
	}
	
	public Boolean isValidHomeAddress(String homeAddress){
		String regex="^([a-zA-Z0-9\\s]+)?$";
		return Pattern.matches(regex,homeAddress);
	}
	
	public Boolean isValidContactNumber(String contactNumber){
		String regex="^([a-zA-Z0-9]+)?$";
		return Pattern.matches(regex,contactNumber);
	} 
	
}
