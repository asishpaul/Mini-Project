package org.cap.model;

public class DepartmentBean {
	
	private Integer Dept_ID;
	private String Dept_Name;
	
	public DepartmentBean() {
		super();
	}

	public DepartmentBean(Integer dept_ID, String dept_Name) {
		super();
		Dept_ID = dept_ID;
		Dept_Name = dept_Name;
	}

	public Integer getDept_ID() {
		return Dept_ID;
	}

	public void setDept_ID(Integer dept_ID) {
		Dept_ID = dept_ID;
	}

	public String getDept_Name() {
		return Dept_Name;
	}

	public void setDept_Name(String dept_Name) {
		Dept_Name = dept_Name;
	}

	@Override
	public String toString() {
		return "Department [Dept_ID=" + Dept_ID + ", Dept_Name=" + Dept_Name + "]";
	}
	
	

}
