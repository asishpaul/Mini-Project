package org.cap.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.cap.exception.EmployeeMaintenanceSystemException;
import org.cap.model.DepartmentBean;
import org.cap.model.EmployeeBean;
import org.cap.service.EMSServiceImpl;
import org.cap.service.IEMSService;
import org.cap.service.Validation;

public class User {

	public static void main(String[] args) throws EmployeeMaintenanceSystemException {

		IEMSService service =new EMSServiceImpl();
		EmployeeBean bean=new EmployeeBean();
		Scanner sc=new Scanner(System.in);
		Validation validator=new Validation();
		while(true){
			System.out.println("Enter your choice: ");
			System.out.println("1. Admin Login");
			System.out.println("2. Employee Login");
			System.out.println("3. Exit");
			Integer choice = sc.nextInt();
			switch (choice) {
			case 1://Admin Menu
				System.out.println("Enter your name: ");
				sc.nextLine();
				String nameAdmin=sc.nextLine();
				//System.out.println(name);
				System.out.println("Enter your password: ");
				String passwordAdmin=sc.nextLine();

				if(service.isValidAdmin(nameAdmin, passwordAdmin)){
					System.out.println("Login Successful : ");
					System.out.println("1.Add employee:");
					System.out.println("2.Modify Employee");
					System.out.println("3.Show All Employee..");
					Integer adminChoice=sc.nextInt();
					switch(adminChoice){
					case 1://Add New Employee
						System.out.println("Enter EmpId: ");
						sc.nextLine();
						String empId=sc.nextLine();
						//System.out.println(empId);
						if(validator.isValidEmpId(empId)){
							System.out.println("Enter empFirstName: ");

							String empFirstName=sc.nextLine();

							if(validator.isValidFirstName(empFirstName)){
								//System.out.println(empFirstName);

								System.out.println("Enter empLastName: ");
								String empLastName=sc.nextLine();

								if(validator.isValidLastName(empLastName)){

									System.out.println("Enter empDateOfBirth: ");
									String empDateOfBirth=sc.nextLine();
									DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
									LocalDate DOB=LocalDate.parse(empDateOfBirth,formatter);
									System.out.println(empDateOfBirth);

									System.out.println("Enter empDateOfJoining");
									String empDateOfJoining=sc.nextLine();
									DateTimeFormatter formatter1=DateTimeFormatter.ofPattern("dd/MM/yyyy");
									LocalDate DOJ=LocalDate.parse(empDateOfJoining,formatter1);
									System.out.println(empDateOfJoining);

									System.out.println("Department Details:");
									List<DepartmentBean> bean1=service.displayDepartmentDetails();
									System.out.println(bean1);

									System.out.println("Enter empDeptId: ");
									Integer empDeptId=sc.nextInt();
									System.out.println(empDeptId);

									System.out.println("Enter empGrade: ");
									sc.nextLine();
									String empGrade=sc.nextLine();
									System.out.println(empGrade);

									if(validator.isValidGrade(empGrade)){

										System.out.println("Enter empDesignation: ");
										String empDesignation=sc.nextLine();
										System.out.println(empDesignation);

										System.out.println("Enter empBasic: ");
										Integer empBasic=sc.nextInt();
										System.out.println(empBasic);

										System.out.println("Enter empGender: ");
										sc.nextLine();
										String empGender=sc.nextLine();
										System.out.println(empGender);

										if(validator.isValidGender(empGender)){

											System.out.println("Enter empMaritalStatus: ");
											String empMaritalStatus=sc.nextLine();
											System.out.println(empMaritalStatus);

											if(validator.isValidMartialStatus(empMaritalStatus)){
												
												System.out.println("Enter empHomeAddress: ");
												String empHomeAddress=sc.nextLine();
												System.out.println(empHomeAddress);
											if(validator.isValidHomeAddress(empHomeAddress)){
												
												System.out.println("Enter empContactNum: ");
												String empContactNum=sc.nextLine();
												System.out.println(empContactNum);
											if(validator.isValidContactNumber(empContactNum)){
												bean.setEmpId(empId);
												bean.setEmpFirstName(empFirstName);
												bean.setEmpLastName(empLastName);						


												bean.setEmpDateOfBirth(DOB);


												bean.setEmpDateOfJoining(DOJ);


												bean.setEmpDeptId(empDeptId);
												bean.setEmpGrade(empGrade);
												bean.setEmpDesignation(empDesignation);
												bean.setEmpBasic(empBasic);
												bean.setEmpGender(empGender);
												bean.setEmpMaritalStatus(empMaritalStatus);
												bean.setEmpHomeAddress(empHomeAddress);
												bean.setEmpContactNum(empContactNum);

												int n=service.addEmployeeDetails(bean);
												if(n!=0) {
													System.out.println("Succesfully inserted");
												}
											}
											else{
												System.out
														.println("Enter Valid Contact No..");
											}
											}
											else{
												System.out
														.println("Enter Valid Home Address...");
											}
											}
											else{
												System.out.println("Enter Valid Marital Status");
											}
										}
										else{
											System.out.println("Enter Valid Gender...");
										}
									}
									else{
										System.out.println("Enter Valid Grade....");
									}
								}
								else
								{
									System.out.println("Enter last name in correct format....");
								}
							}
							else{
								System.out.println("Enter First Name in correct format..");
							}
						}
						else{
							System.out.println("Enter valid Employee ID...");
						}
						break; 

					case 2://Modify Employee
						System.out.println("Enter your employee Id: ");
						sc.nextLine();
						String empid=sc.nextLine();
						System.out.println("Employee Id:"+empid);
						List<EmployeeBean> empBean2=service.getAllEmployeeDetails(empid);
						Iterator<EmployeeBean> iterator1=empBean2.iterator();
						while(iterator1.hasNext()){
							System.out.println(iterator1.next());
						}
						System.out.println("\n");
						System.out.println("Modify your Details here...");
						System.out.println("\n");
						System.out.println("Employee id: "+empid);
						System.out.println("Enter new First Name: ");

						String fname=sc.nextLine();
						System.out.println("New First Name:"+fname);

						System.out.println("Enter New Last Name:");
						String lname=sc.nextLine();
						System.out.println("New Last Name:"+lname);

						System.out.println("Enter New Dept Id: ");
						Integer deptId=sc.nextInt();
						System.out.println("New Dept Id: "+deptId);

						System.out.println("Enter new Grade:");
						sc.nextLine();
						String grade=sc.nextLine();
						System.out.println("New grade:"+grade);

						System.out.println("Enter new Designation: ");
						String designation=sc.nextLine();
						System.out.println("New Designation: "+designation);

						System.out.println("Enter New Basic: ");
						Integer basic=sc.nextInt();
						System.out.println("New Basic: "+basic);

						System.out.println("Enter updated Marital status: ");
						sc.nextLine();
						String maritalStatus=sc.nextLine();
						System.out.println("Updated Marital status: "+maritalStatus);

						System.out.println("Enter Updated Home address: ");
						String hAddress=sc.nextLine();
						System.out.println("Updated Home address: "+hAddress);

						System.out.println("Enter Updated contact no: ");
						String contact=sc.nextLine();
						System.out.println("Updated Home address: "+contact);

						Integer Update=service.UpdateDetails(empid,fname,lname,deptId,grade,designation,basic,maritalStatus,hAddress,contact);

						if(Update>0){
							System.out.println("Updated Successfully...");
						}
						else{
							System.out.println("Failed to Update...");
						}
						break;

					case 3:
						List<EmployeeBean> empBean1=service.getAllEmployeeDetails();

						Iterator<EmployeeBean> iterator=empBean1.iterator();

						while(iterator.hasNext()){
							System.out.println(iterator.next());
						}
					}
				}


				else System.out.println("Enter valid username and password");
				break;

				//Client Menu
			case 2:
				System.out.println("Enter your name: ");
				sc.nextLine();
				String name=sc.nextLine();
				System.out.println(name);
				System.out.println("Enter your password: ");
				String password=sc.nextLine();

				if(service.isValidEmployee(name, password)){
					System.out.println("Login Successful :) ");
					System.out.println("1.Search for the Employee:");
					System.out.println("2.LogOut");

					Integer userChoice=sc.nextInt();
					switch(userChoice){

					case 1://Employee Searching
						System.out.println("Select your choice:...");
						System.out.println("1.Search based on Employee Id:");
						System.out.println("2.Search based on First Name:");
						System.out.println("3.Search based on Department.");
						System.out.println("4.Search based on Grade:");
						System.out.println("5.Search based on Marital Status:");
						int uchoice=sc.nextInt();
						switch(uchoice){
						case 1://Searching using EMP_ID
							System.out.println("Enter your employee Id: ");
							sc.nextLine();
							String empid=sc.nextLine();
							System.out.println("Employee Id:"+empid);
							List<EmployeeBean> empBean2=service.getAllEmployeeDetails(empid);
							Iterator<EmployeeBean> iterator1=empBean2.iterator();
							while(iterator1.hasNext()){
								System.out.println(iterator1.next());
							}
							System.out.println();
							break;
						case 2://Searching using First_name
							System.out.println("Enter your First name: ");
							sc.nextLine();
							String fname=sc.nextLine();
							System.out.println("Employee name:"+fname);
							List<EmployeeBean> empBean3=service.getAllEmployeeDetails1(fname);
							Iterator<EmployeeBean> iterator2=empBean3.iterator();
							while(iterator2.hasNext()){
								System.out.println(iterator2.next());
							}
							System.out.println();
							break;
						case 3:
							System.out.println("Enter Dept Id: ");
							Integer deptId=sc.nextInt();
							System.out.println("Your dept id: "+deptId);
							List<EmployeeBean> empBean4=service.getAllEmployeeDetails2(deptId);
							System.out.println(empBean4);
						case 4:
							System.out.println("Enter Grade: ");
							sc.nextLine();
							String grade=sc.nextLine();
							System.out.println("Your Grade: "+grade);
							List<EmployeeBean> empBean5=service.getAllEmployeeDetailsGrade(grade);
							System.out.println(empBean5);
						case 5:
							System.out.println("Enter Your Marital Status: ");
							sc.nextLine();
							String marital=sc.nextLine();
							System.out.println("Your Status :"+marital);
							List<EmployeeBean> empBean6=service.getAllEmployeeDetailsStatus(marital);
							System.out.println(empBean6);
						}
						break;
					case 2://exit from employee
						System.exit(0);
						break;
					}

				}
				else System.out.println("Enter valid username and password");
				break;

			case 3://exit from system
				System.exit(0);
			default:
				System.out.println("Invalid Choice");


			}

		}

	}

}
