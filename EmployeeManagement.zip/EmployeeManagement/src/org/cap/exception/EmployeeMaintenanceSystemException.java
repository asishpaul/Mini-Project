package org.cap.exception;

public class EmployeeMaintenanceSystemException extends Exception {
	private String message;

	public EmployeeMaintenanceSystemException() {
		super();
	}
	
	
	public EmployeeMaintenanceSystemException(String message) {
		super();
		this.message = message;
	}


	public String getMessage() {
		return message;
	}


	@Override
	public String toString() {
		return "PizzaExceptionmessage=" + message;
	}



	
	

}
